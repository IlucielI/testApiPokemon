<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="icon" href="<?php echo e(URL::asset('icon.ico')); ?>">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

  <link rel="stylesheet" href="<?php echo e(URL::asset('sweetalert/sweetalert2.min.css')); ?>">

  <style>
    section {
      min-height: 420px;
    }
  </style>
  <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="<?php echo e(url ('/')); ?>">Bayu Anugerah</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
        <a class="nav-link <?php if(Request::segment( 1 ) == '' || Request::segment( 1 ) == "pokemon"): ?> active <?php endif; ?>" href="<?php echo e(url ('/')); ?>">Home</a>
          <a class="nav-link <?php if(Request::segment( 1 ) == 'mypokemon'): ?> active <?php endif; ?>" href="<?php echo e(url('/mypokemon')); ?>">MyPokemon</a>
        </div>
      </div>
    </div>
  </nav>
  <div class="container mt-5">
      <?php echo $__env->yieldContent('content'); ?>

  </div>

  


  <script src="<?php echo e(URL::asset('jquery-3.6.0.js')); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
  <script src="<?php echo e(URL::asset('sweetalert/sweetalert2.all.min.js')); ?>"></script>
  <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\testPokemon\resources\views/layout/main.blade.php ENDPATH**/ ?>