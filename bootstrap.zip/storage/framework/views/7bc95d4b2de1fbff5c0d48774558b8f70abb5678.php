<?php
use PokePHP\PokeApi;
$api = new PokeApi;
?>



<?php $__env->startSection('title'); ?>
    Bayu Anugerah
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <?php $__currentLoopData = $data->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
    <div class="col mt-2 d-flex justify-content-center">
        <div class="card" style="width: 18rem;">
        <a href="/pokemon/<?php echo e($result->name); ?>"><img src="<?php echo e($result->sprite); ?>" class="card-img-top" alt="..."></a>
          <div class="card-body">
            <h5 class="card-title text-center"><?php echo e($result->name); ?></h5>
            <a href="/pokemon/<?php echo e($result->name); ?>">
              <button type="button" class="btn btn-info">Detail</button>
            </a>
          </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testPokemon\resources\views/index.blade.php ENDPATH**/ ?>